# Jadwal-Waktu-Shalat-Arduino
Jadwal Waktu Shalat Arduino, mempermudah untuk membuat proyek jadwal waktu shalat menggunakan Arduino.

## Kebutuhan
- Arduino
- RTC DS1307
- Kabel Jumper

## Referensi
- [Prayer Times Library](https://github.com/asmaklad/Arduino-Prayer-Times)
- [Elang Sakti](https://www.elangsakti.com/2017/11/jam-digital-masjid.html)
